
from aiogram import Bot, Dispatcher, types
from aiogram.types import Message, ReplyKeyboardMarkup, KeyboardButton
from aiogram.utils import executor
import logging
import os

# Токен Telegram-бота (замени на свой перед запуском)
API_TOKEN = os.getenv("BOT_TOKEN")

logging.basicConfig(level=logging.INFO)
bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

# Приветственное сообщение
@dp.message_handler(commands=["start", "help"])
async def send_welcome(message: Message):
    kb = ReplyKeyboardMarkup(resize_keyboard=True)
    kb.add(KeyboardButton("О Nomad Suite"), KeyboardButton("Показать номера"))
    await message.reply("Добро пожаловать в Nomad Suite! Чем могу помочь?", reply_markup=kb)

# Ответ на кнопки
@dp.message_handler(lambda message: message.text == "О Nomad Suite")
async def about(message: Message):
    await message.reply("Nomad Suite — апарт-отель в центре Махачкалы. Современный ремонт, удобства, самостоятельное заселение. Адрес: ул. Хаджи Булача, 54. Забронировать: +7 999 419 3999.")

@dp.message_handler(lambda message: message.text == "Показать номера")
async def rooms(message: Message):
    await message.reply("Доступны номера:
- Standard Suite
- Deluxe Suite

Подробности: https://nomadsuite.ru")

# Заглушка на любое другое сообщение
@dp.message_handler()
async def default(message: Message):
    await message.reply("Напишите /start или используйте кнопки ниже.")

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)
